import { NgModule, Inject, InjectionToken, OnInit, Component, Directive, HostBinding, HostListener, Input, Renderer2, ElementRef, Injectable } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule, DOCUMENT } from '@angular/common';

//Injectable
@Injectable()
export class ClassToggle{
    constructor(/*private document: Document, */private renderer: Renderer2){

    }

}

//layout module contents
@Directive({
    selector: '[appHtmlAttr]'
})
export class HtmlAttributesDirective implements OnInit{
    @Input() appHtmlAttr;

    constructor(private renderer: Renderer2, private el: ElementRef){
    }

    ngOnInit(){
        var attribs = this.appHtmlAttr;
        for(var attr in attribs){
            if(attr == 'style' && typeof(attribs[attr]) == 'object'){
                this.setStyle(attribs[attr]);
            } else if( attr =='class'){
                this.addClass(attribs[attr]);
            } else {
                this.setAttrib(attr, attribs[attr]);
            }

        }
    }

    setStyle(styles){
        for(var style in styles){
            this.renderer.setStyle(this.el.nativeElement, style, styles[style])
        }
    }

    addClass(classes){
        var classArray = Array.isArray(classes) ? classes : classes.split(' ');
        classArray.filter((function(element) { return element.length > 0})).forEach(function(element){
            this.renderer.addClass(this.el.nativeElement, element);
        })
    }

    setAttrib(key, value){
        this.renderer.setAttribute(this.el.nativeElement, key, value);
        this.renderer.removeAttribute(this.el.nativeElement, key)
    }
}

//
@Directive({
    selector: '[appSidebarToggler]',
    providers: [ClassToggle]
})
export class SidebarToggleDirective implements OnInit{
    @Input() appHtmlAttr;
    @Input('appSidebarToggler') breakpoint;
    @HostListener('click', ['$event']) toggleOpen;

    constructor(private classToogle: ClassToggle){
    }

    ngOnInit(){

    }
}

//
@Directive({
    selector: '[appAsideMenuToggler]',
    providers: [ClassToggle]
})
export class AsideToggleDirective{
    @Input('appAsideMenuToggler') breakpoint;
    @HostListener('click', ['$event']) toggleOpen($event){

    };

}
 
@NgModule({
    imports: [
        CommonModule
    ],    
    exports: [
        HtmlAttributesDirective,
        SidebarToggleDirective,
        AsideToggleDirective
    ],
    declarations: [
        HtmlAttributesDirective,
        SidebarToggleDirective,
        AsideToggleDirective
    ]
})
export class LayoutModule { }

//Component App Header
@Component({
    selector: 'app-header , cui-header',
    inputs: ['navbarBrandRouterLink',
            'fixed',
            'navbarBrand',
            'navbarBrandFull',
            'navbarBrandMinimized',
            'navbarBrandText',
            'navbarBrandHref',
            'navbarBrandRouterLink',
            'sidebarToggler',
            'mobileSidebarToggler',
            'asideMenuToggler',
            'mobileAsideMenuToggler'],
    template:"<ng-template [ngIf]=\"mobileSidebarToggler != false\">\r\n  <button class=\"navbar-toggler {{sidebarTogglerMobileClass}}\" type=\"button\" appSidebarToggler>\r\n    <span class=\"navbar-toggler-icon\"></span>\r\n  </button>\r\n</ng-template>\r\n<a class=\"navbar-brand\" [routerLink]=\"navbarBrandRouterLink\">\r\n  <ng-template [ngIf]=\"navbarBrandImg\">\r\n    <img *ngIf=\"navbarBrand\"\r\n         [appHtmlAttr]=\"navbarBrand\"\r\n         [ngClass]=\"'navbar-brand'\">\r\n    <img *ngIf=\"navbarBrandFull\"\r\n         [appHtmlAttr]=\"navbarBrandFull\"\r\n         [ngClass]=\"'navbar-brand-full'\">\r\n    <img *ngIf=\"navbarBrandMinimized\"\r\n         [appHtmlAttr]=\"navbarBrandMinimized\"\r\n         [ngClass]=\"'navbar-brand-minimized'\">\r\n  </ng-template>\r\n  <ng-template [ngIf]=\"!navbarBrandImg\">\r\n    <div class=\"navbar-brand-full\" [innerHTML]=\"navbarBrandText.text\"></div>\r\n    <div class=\"navbar-brand-minimized\" [innerHTML]=\"navbarBrandText.icon\"></div>\r\n  </ng-template>\r\n</a>\r\n<ng-template [ngIf]=\"sidebarToggler != false\">\r\n  <button class=\"navbar-toggler {{sidebarTogglerClass}}\" type=\"button\" [appSidebarToggler]=\"sidebarToggler\">\r\n    <span class=\"navbar-toggler-icon\"></span>\r\n  </button>\r\n</ng-template>\r\n<ng-content></ng-content>\r\n<ng-template [ngIf]=\"asideMenuToggler != false\">\r\n  <button class=\"navbar-toggler {{asideTogglerClass}}\" type=\"button\" [appAsideMenuToggler]=\"asideMenuToggler\">\r\n    <span class=\"navbar-toggler-icon\"></span>\r\n  </button>\r\n</ng-template>\r\n<ng-template [ngIf]=\"mobileAsideMenuToggler != false\">\r\n  <button class=\"navbar-toggler {{asideTogglerMobileClass}}\" type=\"button\" appAsideMenuToggler>\r\n    <span class=\"navbar-toggler-icon\"></span>\r\n  </button>\r\n</ng-template>\r\n "
})

export class AppHeaderComponent implements OnInit{
    @HostBinding('class.app-header') _header = true;
    @HostBinding('class.navbar') _navbar = true;
    navbarBrandRouterLink; 
    fixedClass;
    breakpoints;
    sidebarTogglerClass;
    sidebarTogglerMobileClass;
    asideTogglerClass;
    asideTogglerMobileClass;

    @Input() fixed;
    @Input() navbarBrand;
    @Input() navbarBrandFull;
    @Input() navbarBrandMinimized;
    @Input() navbarBrandText;

    @Input() navbarBrandImg;
    //constructor(private document: DOCUMENT, private renderer: Renderer2){
    constructor(@Inject(DOCUMENT) private document: Document, private renderer: Renderer2){
        this.navbarBrandRouterLink = '';
        this.fixedClass = 'header-fixed';
        this._header = true;
        this._navbar = true;
        this.breakpoints = ['xl', 'lg', 'md', 'sm', 'xs'];
        this.sidebarTogglerClass = 'd-none d-md-block';
        this.sidebarTogglerMobileClass = 'd-lg-none';
        this.asideTogglerClass = 'd-none d-md-block';
        this.asideTogglerMobileClass = 'd-lg-none';
    }

    ngOnInit(){
        this.isFixed(this.fixed);
        this.navbarBrandImg = this.navbarBrand || this.navbarBrandFull || this.navbarBrandMinimized;
    }

    isFixed(fixed){
        if(fixed){
            this.renderer.addClass(this.document.body, this.fixedClass);
        }
    }
}

// Module App Header
@NgModule({
    imports: [
        RouterModule,
        CommonModule,
        LayoutModule
    ],
    declarations: [
        AppHeaderComponent
    ],
    exports: [
        AppHeaderComponent,
    ]
})


export class AppHeaderModule{ }

