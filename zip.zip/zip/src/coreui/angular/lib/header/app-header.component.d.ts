import { OnInit, OnDestroy, Renderer2 } from '@angular/core';
export declare class AppHeaderComponent implements OnInit, OnDestroy {
    ngOnInit(): void;
    ngOnDestroy(): void;
}