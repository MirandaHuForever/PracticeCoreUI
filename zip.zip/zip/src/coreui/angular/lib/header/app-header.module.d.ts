export declare class AppHeaderModule{
}