export interface INavData {
    name?: string;
}