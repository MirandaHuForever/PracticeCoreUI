import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DefaultLayoutComponent } from './containers/default-layout/default-layout.component';

const APP_CONTAIONERS = [ DefaultLayoutComponent ];

import {
  AppHeaderModule
} from '../coreui/angular';

@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    AppHeaderModule
  ],
  declarations: [
    AppComponent,
    ...APP_CONTAIONERS
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
