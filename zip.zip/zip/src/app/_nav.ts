import { INavData } from '../coreui/angular/coreui-angular';

export const navItems: INavData[] = [
    {
        name: 'Dashboard'
    }
]